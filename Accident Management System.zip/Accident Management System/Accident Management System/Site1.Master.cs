﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Accident_Management_System
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton1.Visible = false;
                    LinkButton2.Visible = false;
                }
                else if (Session["role"].Equals("driver"))
                {
                    LinkButton1.Visible = true;
                    LinkButton2.Visible = false;
                    Button1.Visible = false;
                    Button2.Visible = false;
                }
                else if (Session["role"].Equals("insurance"))
                {
                    LinkButton1.Visible = true;
                    LinkButton2.Visible = false;
                    Button1.Visible = false;
                    Button2.Visible = false;
                }
                else if (Session["role"].Equals("rda"))
                {
                    LinkButton1.Visible = true;
                    LinkButton2.Visible = false;
                    Button1.Visible = false;
                    Button2.Visible = false;
                }
                else if (Session["role"].Equals("police"))
                {
                    LinkButton1.Visible = true;
                    LinkButton2.Visible = true;
                    Button1.Visible = false;
                    Button2.Visible = false;
                }
                else if (Session["role"].Equals("webmaster"))
                {
                    LinkButton1.Visible = true;
                    LinkButton2.Visible = false;
                    Button1.Visible = false;
                    Button2.Visible = false;
                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["role"] = "";

            LinkButton1.Visible = false;
            LinkButton2.Visible = false;
            Button1.Visible = true;
            Button2.Visible = true;

            Response.Redirect("homepage.aspx");
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("chartview.aspx");
        }
    }

}