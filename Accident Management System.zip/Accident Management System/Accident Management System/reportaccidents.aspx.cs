﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Accident_Management_System
{
    public partial class reportaccidents : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        static string global_filepath;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(checkIfAccidentExists())
            {
                Response.Write("<script>alert('ID Already Exists, try some other Accident ID');</script>");
            }
            else
            {
                addNewAccident();
            }
        }

        bool checkIfAccidentExists()
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("SELECT * from accident_tbl where accident_id='" + TextBox1.Text.Trim() + "';", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                return false;
            }
        }

        void addNewAccident()
        {
            try
            {
                string filepath = "~/accident_inventory/accident.jpg";
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(Server.MapPath("accident_inventory/" + filename));
                filepath = "~/accident_inventory/" + filename;

                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                SqlCommand cmd = new SqlCommand("INSERT INTO accident_tbl(accident_id,vehicle_type,reason,accident_date,accident_location,description,accident_img_link) values(@accident_id,@vehicle_type,@reason,@accident_date,@accident_location,@description,@accident_img_link)", con);

                cmd.Parameters.AddWithValue("@accident_id", TextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@vehicle_type", DropDownList1.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@reason", DropDownList2.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@accident_date", TextBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@accident_location", TextBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@description", TextBox7.Text.Trim());
                cmd.Parameters.AddWithValue("@accident_img_link", filepath);

                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Your Accident Report Added successfully.');</script>");

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            getAccidentByID();
        }
        void getAccidentByID()
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("SELECT * from accident_tbl WHERE accident_id='" + TextBox1.Text.Trim() + "';", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    TextBox2.Text = dt.Rows[0]["accident_date"].ToString();
                    TextBox3.Text = dt.Rows[0]["accident_location"].ToString();
                    TextBox4.Text = dt.Rows[0]["police_approve"].ToString();
                    TextBox5.Text = dt.Rows[0]["rda_approve"].ToString();
                    TextBox6.Text = dt.Rows[0]["insurance_claim"].ToString();
                    TextBox7.Text = dt.Rows[0]["description"].ToString();

                    DropDownList1.SelectedValue = dt.Rows[0]["vehicle_type"].ToString().Trim();
                    DropDownList2.SelectedValue = dt.Rows[0]["reason"].ToString().Trim();

                    global_filepath = dt.Rows[0]["accident_img_link"].ToString();
                }
                else
                {
                    Response.Write("<script>alert('Invalid Book ID');</script>");
                }
            }
            catch(Exception ex)
            {

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            updateAccidentByID();
        }
        void updateAccidentByID()
        {
            if(checkIfAccidentExists())
            {
                try
                {
                    string filepath = "~/accident_inventory/accident";
                    string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    if (filename == "" || filename == null)
                    {
                        filepath = global_filepath;

                    }
                    else
                    {
                        FileUpload1.SaveAs(Server.MapPath("accident_inventory/" + filename));
                        filepath = "~/accident_inventory/" + filename;
                    }

                    SqlConnection con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    SqlCommand cmd = new SqlCommand("UPDATE accident_tbl set vehicle_type=@vehicle_type, reason=@reason, accident_date=@accident_date, accident_location=@accident_location, description=@description, accident_img_link=@accident_img_link where accident_id='" + TextBox1.Text.Trim() + "'", con);

                    cmd.Parameters.AddWithValue("@accident_id", TextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@vehicle_type", DropDownList1.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@reason", DropDownList2.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@accident_date", TextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@accident_location", TextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@description", TextBox7.Text.Trim());
                    cmd.Parameters.AddWithValue("@accident_img_link", filepath);

                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Accident Updated Successfully');</script>");

                }
                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid Accident ID');</script>");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            deleteAccidentByID();
        }
        void deleteAccidentByID()
        {
            if (checkIfAccidentExists())
            {
                try
                {
                    SqlConnection con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    SqlCommand cmd = new SqlCommand("DELETE from accident_tbl WHERE accident_id='" + TextBox1.Text.Trim() + "'", con);

                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Accident Deleted Successfully');</script>");

                }
                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }

            }
            else
            {
                Response.Write("<script>alert('Invalid Accident ID');</script>");
            }
        }
    }
}