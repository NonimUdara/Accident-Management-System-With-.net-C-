﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

namespace Accident_Management_System
{
    public partial class chartview : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadData1();
                LoadData2();
                LoadData3();
                LoadData4();
                LoadData5();
                LoadData6();
            }
        }
        void LoadData1()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select reason, count(vehicle_type) as TotAmount from accident_tbl where vehicle_type='Motorcycle' group by reason  ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }
            Chart1.Series[0].Points.DataBindXY(x, y);
            Chart1.Series[0].ChartType = SeriesChartType.Pie;
        }
        void LoadData2()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select reason, count(vehicle_type) as TotAmount from accident_tbl where vehicle_type='Car' group by reason  ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }
            Chart2.Series[0].Points.DataBindXY(x, y);
            Chart2.Series[0].ChartType = SeriesChartType.Pie;
        }
        void LoadData3()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select reason, count(vehicle_type) as TotAmount from accident_tbl where vehicle_type='Van' group by reason  ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }
            Chart3.Series[0].Points.DataBindXY(x, y);
            Chart3.Series[0].ChartType = SeriesChartType.Pie;
        }
        void LoadData4()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select reason, count(vehicle_type) as TotAmount from accident_tbl where vehicle_type='Bus' group by reason  ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }
            Chart4.Series[0].Points.DataBindXY(x, y);
            Chart4.Series[0].ChartType = SeriesChartType.Pie;
        }
        void LoadData5()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select reason, count(vehicle_type) as TotAmount from accident_tbl where vehicle_type='Lorry' group by reason  ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }
            Chart5.Series[0].Points.DataBindXY(x, y);
            Chart5.Series[0].ChartType = SeriesChartType.Pie;
        }
        void LoadData6()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(strcon);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select reason, count(vehicle_type) as TotAmount from accident_tbl where vehicle_type='Other' group by reason  ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            string[] x = new string[dt.Rows.Count];
            int[] y = new int[dt.Rows.Count];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToInt32(dt.Rows[i][1]);
            }
            Chart6.Series[0].Points.DataBindXY(x, y);
            Chart6.Series[0].ChartType = SeriesChartType.Pie;
        }
    }    
}